package com.sample;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.drools.decisiontable.InputType;
import org.drools.decisiontable.SpreadsheetCompiler;

public class DTConverter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
	FileOutputStream  out=null;
    PrintStream pstream=null;  
		
		
		// create an input stream
		InputStream is =null;
		try {
		// assign the excel to the input stream
		// mention the local directory path where your excel is kept
		// you can take any decision table (excel sheet) for testing
		is= new FileInputStream("F:/drooolsmars/workspace/CreditCardProcess/src/main/resources/tables/Appraisal.xls");
		} catch (FileNotFoundException e) {
		e.printStackTrace();
		}
		// create compiler class instance
		SpreadsheetCompiler sc = new SpreadsheetCompiler();
		// compile the excel to generate the (.drl) file
		String drl=sc.compile(is, InputType.XLS);
		// check the generated (.drl) file
		System.out.println("Generate DRL file is �: ");
		System.out.println(drl);
		try {
			out=new FileOutputStream("F:/drooolsmars/workspace/CreditCardProcess/src/main/resources/rules/test.drl");
		  pstream=new PrintStream(out);
		  pstream.print(drl);
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
