package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import com.sample.entities.Employee;

public class DtableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		 KieServices ks = KieServices.Factory.get();
 	    KieContainer kContainer = ks.getKieClasspathContainer();
     	KieSession kSession = kContainer.newKieSession("ksession-tables");
     	Employee employee =new Employee();
     	employee.setWclientFocusedDelivery(60);
     	employee.setWleadership(14);
     	employee.setWinnovation(7);
     	kSession.insert(employee);
     	  kSession.fireAllRules();
		}
		catch(Throwable t)
		{
			System.out.println(t.getMessage());
		}
	}

}
