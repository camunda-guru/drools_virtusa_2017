package com.sample.entities;

public class Employee {

	private int wclientFocusedDelivery;
	private int wleadership;
	private int winnovation;
	private float rating;
	public int getWclientFocusedDelivery() {
		return wclientFocusedDelivery;
	}
	public void setWclientFocusedDelivery(int wclientFocusedDelivery) {
		this.wclientFocusedDelivery = wclientFocusedDelivery;
	}
	public int getWleadership() {
		return wleadership;
	}
	public void setWleadership(int wleadership) {
		this.wleadership = wleadership;
	}
	public int getWinnovation() {
		return winnovation;
	}
	public void setWinnovation(int winnovation) {
		this.winnovation = winnovation;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	
	
}
